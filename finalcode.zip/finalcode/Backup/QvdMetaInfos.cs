﻿#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
#endregion
namespace QlikViewMeta
{
    public class MetaDataQvd
    {
        #region Public Properties

        /// <summary>
        /// Absolute path of the Qvd file.
        /// </summary>
        public string QvdFilePath { get; private set; }

        /// <summary>
        /// Name of the Qvd file.
        /// </summary>
        public string QvdFileName { get; private set; }

        /// <summary>
        /// QlikView's BuildNo when generating the qvd file.
        /// </summary>
        public int QvBuildNo { get; private set; }

        /// <summary>
        /// Creator of the document.
        /// </summary>
        public string CreatorDoc { get; private set; }

        /// <summary>
        /// Creation date of the qvd file
        /// </summary>
        public DateTime QvdCreateTime { get; private set; }
        
        /// <summary>
        /// Amount of total records within the qvd file.
        /// </summary>
        public long QvdNoOfRecords { get; private set; }
            

        /// <summary>
        /// Amount of fields within the qvd file.
        /// </summary>
        public int QvdNoOfFields
        {
            get
            {
                return this.QvdFields.Count;
            }
        }

        /// <summary>
        /// Name of the table stored in the qvd file.
        /// </summary>
        public string QvdTableName { get; private set; }

        private List<QvdField> _QvdFields;
        /// <summary>
        /// List of fields available in the qvd file.
        /// </summary>
        public List<QvdField> QvdFields 
        { 
            get 
            {
                if (_QvdFields == null)
                {
                    _QvdFields = new List<QvdField>();
                }
                return _QvdFields;
            }
            set 
            {
                _QvdFields = value;
            } 
        }
        #endregion

        #region Constructor
       
        public MetaDataQvd(string qvdFilePath)
        {
            #region Check if file exists ...
            if (!File.Exists(qvdFilePath))
            {
                throw new FileNotFoundException("The qvd file does not exist.", qvdFilePath);            
            }
            #endregion
            this.QvdFilePath = qvdFilePath;
            this.QvdFileName = new FileInfo(qvdFilePath).Name;

             FileStream fs = new FileStream(qvdFilePath, FileMode.Open, FileAccess.Read,FileShare.Read);
             using (StreamReader sr = new StreamReader(fs))
             {
                 string temp;
                 string xmlString = string.Empty; //<= replace this with a stringbuilder
                 while ((temp = sr.ReadLine()) != null)
                 {
                     //Console.WriteLine(temp);
                     xmlString += temp;
                     if (temp.Trim().ToLower() == "</qvdtableheader>".ToLower())
                     {
                         break;
                     }
                 }
                 if (!string.IsNullOrEmpty(xmlString))
                 {
                     InitPropsFromXml(xmlString);
                 }
             }
        }
        #endregion

        #region Interpreting the XML
       
        private void InitPropsFromXml(string xmlMetaInfos)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlMetaInfos);

            #region Retrieve the general values of the xml header

            // QvBuildNo
            this.QvBuildNo = GetNodeValueInt(xmlDoc, "QvdTableHeader/QvBuildNo");            

            // CreatorDoc
            this.CreatorDoc = GetNodeValueString(xmlDoc, "QvdTableHeader/CreatorDoc");
            
            // QvdCreateTime
            this.QvdCreateTime = GetNodeValueCreateTime(xmlDoc, "QvdTableHeader/CreateUtcTime");

            // QvdTableName
            this.QvdTableName = GetNodeValueString(xmlDoc, "QvdTableHeader/TableName");

            // QvdNoOfRecords
            this.QvdNoOfRecords = GetNodeValueInt(xmlDoc, "QvdTableHeader/NoOfRecords");

            #endregion

            #region Retrieve the fields

            string xPathFields = "QvdTableHeader/Fields/QvdFieldHeader";
            XmlNodeList fieldNodes = xmlDoc.SelectNodes(xPathFields);

            if (fieldNodes != null)
            {
                foreach (XmlNode fieldNode in fieldNodes)
                {
                    QvdField newField = new QvdField();

                    #region Retrieve the values for a single field

                    // FieldName
                    newField.FieldName = GetNodeValueString(fieldNode, "FieldName");

                    // BitOffset
                    newField.BitOffset = GetNodeValueInt(fieldNode, "BitOffset");

                    // BitWidth
                    newField.BitWidth = GetNodeValueInt(fieldNode, "BitWidth");

                    // Bias
                    newField.Bias = GetNodeValueInt(fieldNode, "Bias");

                    // NoOfSymbols
                    newField.NoOfSymbols = GetNodeValueInt(fieldNode, "NoOfSymbols");

                    // Offset
                    newField.Offset = GetNodeValueInt(fieldNode, "Offset");

                    // Length
                    newField.Length = GetNodeValueInt(fieldNode, "Length");


                    #region Retrieve the values for NumberFormat
                    string xPathFieldNumberFormat = "NumberFormat";
                    XmlNode nodeFormat = fieldNode.SelectSingleNode(xPathFieldNumberFormat);
                    if (nodeFormat != null)
                    {
                        NumberFormat numberFormat = new NumberFormat();

                        // Type
                        numberFormat.Type = GetNodeValueString(nodeFormat, "Type");

                        // nDec
                        numberFormat.nDec = GetNodeValueInt(nodeFormat, "nDec");

                        // UseThou
                        numberFormat.UseThou = GetNodeValueInt(nodeFormat, "UseThou");

                        // Fmt
                        numberFormat.Fmt = GetNodeValueString(nodeFormat, "Fmt");

                        // Dec
                        numberFormat.Dec = GetNodeValueString(nodeFormat, "Dec");

                        // Thou
                        numberFormat.Thou = GetNodeValueString(nodeFormat, "Thou");

                        newField.NumberFormat = numberFormat;
                    }
                    #endregion

                    this.QvdFields.Add(newField);

                    #endregion
                }
            }




            #endregion
        }
        #endregion

        #region Private Helpers

      
        private string GetNodeValueString(XmlDocument xmlDoc, string xPath)
        {
            XmlNode nodeTableName = xmlDoc.SelectSingleNode(xPath);
            return (nodeTableName != null) ? nodeTableName.InnerText : string.Empty;
        }
        private string GetNodeValueString(XmlNode xmlNode, string xPath)
        {
            XmlNode nodeTableName = xmlNode.SelectSingleNode(xPath);
            return (nodeTableName != null) ? nodeTableName.InnerText : string.Empty;
        }
        private int GetNodeValueInt(XmlDocument xmlDoc, string xPath)
        {
            XmlNode nodeTableName = xmlDoc.SelectSingleNode(xPath);
            int r;
            return (nodeTableName != null && int.TryParse(nodeTableName.InnerText, out r)) ? int.Parse(nodeTableName.InnerText) : -1;
        }
        private int GetNodeValueInt(XmlNode xmlNode, string xPath)
        {
            XmlNode nodeTableName = xmlNode.SelectSingleNode(xPath);
            int r;
            return (nodeTableName != null && int.TryParse(nodeTableName.InnerText, out r)) ? int.Parse(nodeTableName.InnerText) : -1;
        }
        private DateTime GetNodeValueCreateTime(XmlDocument xmlDoc, string xPath)
        {
            XmlNode nodeTableName = xmlDoc.SelectSingleNode(xPath);
            DateTime d;
            return (nodeTableName != null && DateTime.TryParse(nodeTableName.InnerText, out d)) ? DateTime.Parse(nodeTableName.InnerText) : DateTime.MinValue;
        }

        #endregion

    } // (end class MetaDataQvd)
    public class QvdField
    {
        #region Public Properties
        public string FieldName { get; set; }
        public int BitOffset { get; set; }
        public int BitWidth { get; set; }
        public int Bias { get; set; }
        public int Length { get; set; }
        public int NoOfSymbols { get; set; }
        public int Offset { get; set; }

        private NumberFormat _NumberFormat;
        public NumberFormat NumberFormat 
        { 
            get
            {
                if (_NumberFormat == null)
                {
                    _NumberFormat = new NumberFormat();
                }
                return _NumberFormat;
            }
            set
            {
                _NumberFormat = value;
            }
        }

        #endregion
    } // (end class Field)
    public class NumberFormat
    {
        #region Public Properties
        /// <summary>
        /// The type of the field.
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Amount of decimal places.
        /// </summary>
        public int nDec { get; set; }

        /// <summary>
        /// Use thousands separators or not.
        /// </summary>
        public int UseThou { get; set; }

        /// <summary>
        /// Format string.
        /// </summary>
        public string Fmt { get; set; }

        /// <summary>
        /// The decimal separator.
        /// </summary>
        public string Dec { get; set; }

        /// <summary>
        /// The thousands separator.
        /// </summary>
        public string Thou { get; set; }
        #endregion
    } // (end class NumberFormat)
}
