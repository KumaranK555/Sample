﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Partial Class VB
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            gvCustomers.DataSource = GetData("select top 10 * from Customers")
            gvCustomers.DataBind()
        End If
    End Sub

    Private Shared Function GetData(query As String) As DataTable
        Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand()
                cmd.CommandText = query
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using ds As New DataSet()
                        Dim dt As New DataTable()
                        sda.Fill(dt)
                        Return dt
                    End Using
                End Using
            End Using
        End Using
    End Function

    Protected Sub Show_Hide_OrdersGrid(sender As Object, e As EventArgs)
        Dim imgShowHide As ImageButton = TryCast(sender, ImageButton)
        Dim row As GridViewRow = TryCast(imgShowHide.NamingContainer, GridViewRow)
        If imgShowHide.CommandArgument = "Show" Then
            row.FindControl("pnlOrders").Visible = True
            imgShowHide.CommandArgument = "Hide"
            imgShowHide.ImageUrl = "~/images/minus.png"
            Dim customerId As String = gvCustomers.DataKeys(row.RowIndex).Value.ToString()
            Dim gvOrders As GridView = TryCast(row.FindControl("gvOrders"), GridView)
            BindOrders(customerId, gvOrders)
        Else
            row.FindControl("pnlOrders").Visible = False
            imgShowHide.CommandArgument = "Show"
            imgShowHide.ImageUrl = "~/images/plus.png"
        End If
    End Sub

    Private Sub BindOrders(customerId As String, gvOrders As GridView)
        gvOrders.ToolTip = customerId
        gvOrders.DataSource = GetData(String.Format("select * from Orders where CustomerId='{0}'", customerId))
        gvOrders.DataBind()
    End Sub

    Protected Sub OnOrdersGrid_PageIndexChanging(sender As Object, e As GridViewPageEventArgs)
        Dim gvOrders As GridView = TryCast(sender, GridView)
        gvOrders.PageIndex = e.NewPageIndex
        BindOrders(gvOrders.ToolTip, gvOrders)
    End Sub


    Protected Sub Show_Hide_ProductsGrid(sender As Object, e As EventArgs)
        Dim imgShowHide As ImageButton = TryCast(sender, ImageButton)
        Dim row As GridViewRow = TryCast(imgShowHide.NamingContainer, GridViewRow)
        If imgShowHide.CommandArgument = "Show" Then
            row.FindControl("pnlProducts").Visible = True
            imgShowHide.CommandArgument = "Hide"
            imgShowHide.ImageUrl = "~/images/minus.png"
            Dim orderId As Integer = Convert.ToInt32(TryCast(row.NamingContainer, GridView).DataKeys(row.RowIndex).Value)
            Dim gvProducts As GridView = TryCast(row.FindControl("gvProducts"), GridView)
            BindProducts(orderId, gvProducts)
        Else
            row.FindControl("pnlProducts").Visible = False
            imgShowHide.CommandArgument = "Show"
            imgShowHide.ImageUrl = "~/images/plus.png"
        End If
    End Sub

    Private Sub BindProducts(orderId As Integer, gvProducts As GridView)
        gvProducts.ToolTip = orderId.ToString()
        gvProducts.DataSource = GetData(String.Format("SELECT ProductId, ProductName FROM Products WHERE ProductId IN (SELECT ProductId FROM [Order Details] WHERE OrderId = '{0}')", orderId))
        gvProducts.DataBind()
    End Sub

    Protected Sub OnProductsGrid_PageIndexChanging(sender As Object, e As GridViewPageEventArgs)
        Dim gvProducts As GridView = TryCast(sender, GridView)
        gvProducts.PageIndex = e.NewPageIndex
        BindProducts(Integer.Parse(gvProducts.ToolTip), gvProducts)
    End Sub
End Class

