﻿namespace QReader
{
    partial class Result
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.imgLogo = new System.Windows.Forms.PictureBox();
            this.lblNumofRecords = new System.Windows.Forms.Label();
            this.lblSplitedFiles = new System.Windows.Forms.Label();
            this.lblInsertFiles = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // imgLogo
            // 
            this.imgLogo.Image = global::QReader.Properties.Resources.logo;
            this.imgLogo.Location = new System.Drawing.Point(22, 12);
            this.imgLogo.Name = "imgLogo";
            this.imgLogo.Size = new System.Drawing.Size(342, 159);
            this.imgLogo.TabIndex = 0;
            this.imgLogo.TabStop = false;
            // 
            // lblNumofRecords
            // 
            this.lblNumofRecords.AutoSize = true;
            this.lblNumofRecords.Location = new System.Drawing.Point(22, 188);
            this.lblNumofRecords.Name = "lblNumofRecords";
            this.lblNumofRecords.Size = new System.Drawing.Size(0, 13);
            this.lblNumofRecords.TabIndex = 1;
            // 
            // lblSplitedFiles
            // 
            this.lblSplitedFiles.AutoSize = true;
            this.lblSplitedFiles.Location = new System.Drawing.Point(22, 224);
            this.lblSplitedFiles.Name = "lblSplitedFiles";
            this.lblSplitedFiles.Size = new System.Drawing.Size(0, 13);
            this.lblSplitedFiles.TabIndex = 2;
            // 
            // lblInsertFiles
            // 
            this.lblInsertFiles.AutoSize = true;
            this.lblInsertFiles.Location = new System.Drawing.Point(22, 263);
            this.lblInsertFiles.Name = "lblInsertFiles";
            this.lblInsertFiles.Size = new System.Drawing.Size(0, 13);
            this.lblInsertFiles.TabIndex = 3;
            // 
            // Result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 386);
            this.Controls.Add(this.lblInsertFiles);
            this.Controls.Add(this.lblSplitedFiles);
            this.Controls.Add(this.lblNumofRecords);
            this.Controls.Add(this.imgLogo);
            this.Name = "Result";
            this.Text = "Result";
            this.Load += new System.EventHandler(this.Result_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox imgLogo;
        private System.Windows.Forms.Label lblNumofRecords;
        private System.Windows.Forms.Label lblSplitedFiles;
        private System.Windows.Forms.Label lblInsertFiles;
    }
}