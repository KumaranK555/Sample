﻿
#region Using Directives
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using QlikView;
using System.Data.OleDb;
using System.Globalization;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
//using System.Data.OracleClient;
using Oracle.DataAccess.Client;
#endregion
namespace QReader
{
    public partial class frmQReader : Form
    {

        #region "QlikView Variables"
        private QlikView.Application objQVApp = null;
        private QlikView.Doc IDoc = null;
        private QlikView.Variable IQvVariables = null;
        private QlikViewMeta.MetaDataQvd objMetaInformation = null;


        #endregion
        #region "Sql Server Variables"
        private SqlConnection _dconn = null;
        #endregion
        #region "Oracle Variables"
        private OracleConnection _OracleCon = null;

        #endregion
        #region "MySql variables"
        #endregion
        #region "DB2Variables"
        #endregion
        #region "App Settings Variables"
        private string strQvdPath = System.Configuration.ConfigurationSettings.AppSettings["QvdPath"].ToString();
        private string strQvdName = System.Configuration.ConfigurationSettings.AppSettings["QvdsName"].ToString();
        private string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString.ToString();
        private int dbType = Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings["DbType"].ToString());
        private long RowsLimit = Convert.ToInt64(System.Configuration.ConfigurationSettings.AppSettings["RowsLimit"].ToString());
        private string performanceView = System.Configuration.ConfigurationSettings.AppSettings["QvdReadView"].ToString();
        private string connOracle = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionStringOracle"].ConnectionString.ToString();
        private string qvExcPath = System.Configuration.ConfigurationManager.AppSettings["QlikViewExePath"].ToString();
        private int chunkLimit = Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings["ChunkLimit"].ToString());
        private string DateFormat = System.Configuration.ConfigurationSettings.AppSettings["DateForMatOracle"].ToString();

        public static string ScheduleQvdName = string.Empty;
        public static string ScheduleQvdPath = string.Empty;
        public static string ScheduleTime = string.Empty;
        #endregion


        #region "Common Variables"
        private string vCurrnetWD = Environment.CurrentDirectory.ToString();
        private DataTable dt = null;
        DataTable dtBindRecords = null;
        string TableExists = null;
        string exists = null;
        bool columnExsistsStatus = false;
        #endregion
        #region "Methods"
        #region "QlikView Methods"

        public string SelectQvdFile()
        {
            string filePath = "";
            try
            {
                FolderBrowserDialog _folderBrowserDialog1 = new FolderBrowserDialog();
                if (_folderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    filePath = _folderBrowserDialog1.SelectedPath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return filePath;
        }

        private void DirectLoadQvdData(string pQvdName, long totalNoOfrecords, string dbTableName)
        {
            try
            {
                long j = 0;
                double k = Math.Floor((double)totalNoOfrecords / RowsLimit);
                if (k <= 0)
                {
                    RowsLimit = totalNoOfrecords;
                }
                while (j <= totalNoOfrecords)
                {
                    QlikView.Doc IDoc = new QlikView.Document();
                    IDoc = (QlikView.Doc)objQVApp.OpenDocEx(vCurrnetWD + @"\QvdLoader.qvw", 0, false, "", "", "9108 6600 9616 4267", false);
                    IDoc.Activate();
                    IQvVariables = (QlikView.Variable)IDoc.Variables("vQvdName");

                    IQvVariables.SetContent("tmpQvd:" + Environment.NewLine + " Load * from [" + strQvdPath + @"\" + pQvdName + "](qvd) where recno()>" + j + " and recno()<=" + RowsLimit + ";", true);
                    //IDoc.Reload(1);
                    IDoc.ReloadEx(2, 1);
                    LoadQvdToDataTable(IDoc, dbTableName);
                    IDoc.CloseDoc();
                    j = RowsLimit;
                    RowsLimit = RowsLimit + RowsLimit;
                }
                MessageBox.Show("File successfully uploaded...!!", "Upload File");
                Globle._globalValue = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.InnerException.Message);
            }
            finally
            {

            }
        }

        private void IntermediateLoad(string pQvdName, double noOfRows, string dbTableName, string strQvdPath)
        {
            Result frmResult = new Result();
            TableExists = null;
            exists = null;
            try
            {
                IDoc = (QlikView.Doc)objQVApp.OpenDocEx(vCurrnetWD + @"\QvdLoader.qvw", 0, false, "", "", "9108 6600 9616 4267", false);
                IDoc.Activate();
                IQvVariables = (QlikView.Variable)IDoc.Variables("vQvdName");
                IQvVariables.SetContent("set ErrorMode=0;  tmpQvd:" + Environment.NewLine + " Load * from [" + strQvdPath + @"\" + pQvdName + "](qvd);if ScriptError=2 or ScriptError=3 or ScriptError=4 or ScriptError=5 or ScriptError=6 or ScriptError=7 or ScriptError=8 or ScriptError=9 or ScriptError=10 then " + Environment.NewLine + " exit script" + Environment.NewLine + "else" + Environment.NewLine + "store tmpQvd into " + vCurrnetWD + @"\tmp\tmpQvd.csv(txt, delimiter is ',');" + Environment.NewLine + " end if ; ", false);
                //IQvVariables.SetContent("ODBC CONNECT TO [ODBCOracleConnect;DBQ=MYDB](XUserID is qvddata, XPassword is qvd1234$, mode is write);TABLE:LOAD * FROM [D:Files\\TestingQVD\\Test.qvd] (qvd);LET V_ROWS = NoOfRows('TABLE');FOR V_ROW = 0 TO V_ROWS - 1LET V_FIELD1 = Peek('Id',V_ROW);LET V_FIELD2 = Peek('Name',V_ROW);LET V_FIELD3 = Peek('Description',V_ROW);SQL INSERT INTO SampleTable(Id, Name,Description) VALUES ('$(V_FIELD1)', '$(V_FIELD2)', '$(V_FIELD3)');NEXT;", true);
                IDoc.ReloadEx(2, 1);
                IDoc.CloseDoc();
                if (noOfRows > 0)
                {
                    if (frmSchedule.ChunkLimit == 0)
                    {
                        frmSchedule.ChunkLimit = chunkLimit;
                    }
                    double cLimit = Math.Floor((double)noOfRows / frmSchedule.ChunkLimit);
                    SplitCSV(vCurrnetWD + @"\tmp\tmpQvd.csv", (int)cLimit + 1, frmSchedule.ChunkLimit);
                    File.Delete(vCurrnetWD + @"\tmp\tmpQvd.csv");
                    for (int i = 1; i < frmSchedule.ChunkLimit + 1; i++)
                    {
                        ExportToDb(GetCSVRows(vCurrnetWD + @"\tmp\tmpQvd_" + i + ".csv", true), dbTableName);
                        File.Delete(vCurrnetWD + @"\tmp\tmpQvd_" + i + ".csv");
                        frmResult.RecordsText = "CSV Files Created with  " + i + "  Records";
                        frmResult.InsertText = i + "/" + i + "  Files are Inserted";
                    }

                    if (dbTableName == "Prod_Main")
                    {
                        try
                        {
                            using (_OracleCon = new OracleConnection(connOracle))
                            {
                                _OracleCon.Open();

                                OracleCommand addcolumn = new OracleCommand("ALTER TABLE " + dbTableName + " ADD STATECODE VARCHAR2 (1000)", _OracleCon);
                                addcolumn.ExecuteNonQuery();

                                OracleCommand addcolumn1 = new OracleCommand("ALTER TABLE " + dbTableName + " ADD SORTID INT", _OracleCon);
                                addcolumn1.ExecuteNonQuery();

                                OracleCommand addcolumn2 = new OracleCommand("ALTER TABLE " + dbTableName + " ADD LINKCITYSORTID INT", _OracleCon);
                                addcolumn2.ExecuteNonQuery();
                            }
                            UpdateNewColumn(dbTableName);
                            ChangeDataType(dbTableName);
                        }
                        catch (Exception Ex)
                        {
                            MessageBox.Show(Ex.Message);
                        }
                    }
                    using (_OracleCon = new OracleConnection(connOracle))
                    {
                        _OracleCon.Open();
                        if (TableExists != null && TableExists != "No")
                        {
                            OracleCommand cmd4 = new OracleCommand("DROP TABLE " + dbTableName + DateTime.Now.ToString("ddMMyy"), _OracleCon);
                            cmd4.ExecuteNonQuery();
                        }
                    }
                    //MessageBox.Show("File successfully uploaded...!!", "Upload File");
                    string strLogData = "File successfully uploaded At " + DateTime.Now;
                    File.AppendAllText(Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath) + "//log.txt", strLogData);
                    Globle._globalValue = "";
                    frmResult.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                //MessageBox.Show(ex.InnerException.Message);   
                MessageBox.Show(ex.ToString());
            }
        }

        public bool ColumnExists(string TableName)
        {
            string ColumnExists = string.Empty;
            string Column1Exists = string.Empty;
            string Column2Exists = string.Empty;
            //bool result = false;
            try
            {
                using (_OracleCon = new OracleConnection(connOracle))
                {
                    _OracleCon.Open();
                    OracleCommand cmd = new OracleCommand("Select count(*) from user_tab_cols where column_name = 'STATECODE' and table_name = '" + TableName.ToUpper() + "'", _OracleCon);
                    ColumnExists = cmd.ExecuteScalar().ToString();

                    OracleCommand cmd1 = new OracleCommand("Select count(*) from user_tab_cols where column_name = 'SORTID' and table_name = '" + TableName.ToUpper() + "'", _OracleCon);
                    Column1Exists = cmd1.ExecuteScalar().ToString();

                    OracleCommand cmd2 = new OracleCommand("Select count(*) from user_tab_cols where column_name = 'LINKCITYSORTID' and table_name = '" + TableName.ToUpper() + "'", _OracleCon);
                    Column2Exists = cmd2.ExecuteScalar().ToString();
                }
                if (ColumnExists == "1" && Column1Exists == "1" && Column2Exists == "1")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception Ex)
            {
                return false;
            }
        }

        public void UpdateNewColumn(string TableName)
        {
            try
            {
                using (_OracleCon = new OracleConnection(connOracle))
                {
                    _OracleCon.Open();
                    OracleCommand cmd = new OracleCommand("UPDATE " + TableName.ToUpper() + " SET STATECODE = (CASE " +
                    "WHEN STATE_LINK in ('Madhya Pradesh','Chhattisgarh') THEN 'MPCG' " +
                    "WHEN STATE_LINK in ('Rajasthan') THEN 'Rajasthan'" +
                    "WHEN STATE_LINK in ('Chandigarh','Shimla','Haryana','Faridabad','Punjab','Jammu','Noida') THEN 'CPH2'" +
                    "WHEN STATE_LINK in ('Jharkhand') THEN 'Jharkhand'" +
                    "WHEN STATE_LINK in ('Bihar') THEN 'Bihar'" +
                    "WHEN STATE_LINK in ('Gujarat') THEN 'Gujarat'" +
                    "WHEN STATE_LINK in ('Maharashtra') THEN 'Maharashtra'" +
                    "WHEN STATE_LINK in ('MPPR') THEN 'MPPR'" +
                    "ELSE STATE_LINK END)", _OracleCon);
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();

                    OracleCommand cmd1 = new OracleCommand("UPDATE " + TableName.ToUpper() + " SET SORTID = (CASE " +
                    "WHEN STATE_LINK = 'POST' THEN 0 " + 
                    "WHEN STATE_LINK = 'Madhya Pradesh' THEN 1 " +
                    "WHEN STATE_LINK = 'Chhattisgarh' THEN 2" +
                    "WHEN STATE_LINK = 'Rajasthan' THEN 3" +
                    "WHEN STATE_LINK = 'Chandigarh' THEN 4" +
                    "WHEN STATE_LINK = 'Shimla' THEN 5" +
                    "WHEN STATE_LINK = 'Haryana' THEN 6" +
                    "WHEN STATE_LINK = 'Faridabad' THEN 7" +
                    "WHEN STATE_LINK = 'Punjab' THEN 8" +
                    "WHEN STATE_LINK = 'Jammu' THEN 9" +
                    "WHEN STATE_LINK = 'Jharkhand' THEN 10" +
                    "WHEN STATE_LINK = 'Bihar' THEN 11" +
                    "WHEN STATE_LINK = 'Gujarat' THEN 12" +
                    "WHEN STATE_LINK = 'Maharashtra' THEN 13" +
                    "WHEN STATE_LINK = 'MPPR' THEN 14" +
                    "WHEN STATE_LINK = 'Noida' THEN 15" +
                    "WHEN STATE_LINK = 'DNA' THEN 16" +
                    "WHEN STATE_LINK = 'AGRO' THEN 17" +
                    "WHEN STATE_LINK = 'FUN BHASKAR' THEN 19" +
                    "WHEN STATE_LINK = 'YO MAGAZINE' THEN 20" +
                    "WHEN STATE_LINK = 'BBYB' THEN 21" +
                    "WHEN STATE_LINK = 'YBAH' THEN 22" +
                    "END)", _OracleCon);
                    cmd1.ExecuteNonQuery();
                    cmd1.Dispose();

                    OracleCommand cmd2 = new OracleCommand("UPDATE " + TableName.ToUpper() + " SET LINKCITYSORTID = (CASE " +
                    "WHEN LINKCITY1 = 'BHOP' THEN 1" +
                    "WHEN LINKCITY1 = 'HOSH' THEN 2" +
                    "WHEN LINKCITY1 = 'SAGA' THEN 3" +
                    "WHEN LINKCITY1 = 'INDO' THEN 4" +
                    "WHEN LINKCITY1 = 'KHAN' THEN 5" +
                    "WHEN LINKCITY1 = 'UJJA' THEN 6" +
                    "WHEN LINKCITY1 = 'RATL' THEN 7" +
                    "WHEN LINKCITY1 = 'GWAL' THEN 8" +
                    "WHEN LINKCITY1 = 'RAIP' THEN 9" +
                    "WHEN LINKCITY1 = 'DURG' THEN 10" +
                    "WHEN LINKCITY1 = 'BILA' THEN 11" +
                    "WHEN LINKCITY1 = 'RAIG' THEN 12" +
                    "WHEN LINKCITY1 = 'JAIP' THEN 13" +
                    "WHEN LINKCITY1 = 'ALWA' THEN 14" +
                    "WHEN LINKCITY1 = 'BHAR' THEN 15" +
                    "WHEN LINKCITY1 = 'SIKA' THEN 16" +
                    "WHEN LINKCITY1 = 'AJME' THEN 17" +
                    "WHEN LINKCITY1 = 'BHIL' THEN 18" +
                    "WHEN LINKCITY1 = 'BIKA' THEN 19" +
                    "WHEN LINKCITY1 = 'JODH' THEN 20" +
                    "WHEN LINKCITY1 = 'BARM' THEN 21" +
                    "WHEN LINKCITY1 = 'PALI' THEN 22" +
                    "WHEN LINKCITY1 = 'NAGO' THEN 23" +
                    "WHEN LINKCITY1 = 'KOTA' THEN 24" +
                    "WHEN LINKCITY1 = 'UDAI' THEN 25" +
                    "WHEN LINKCITY1 = 'BANS' THEN 26" +
                    "WHEN LINKCITY1 = 'SRIG' THEN 27" +
                    "WHEN LINKCITY1 = 'DBPS JAIP' THEN 28" +
                    "WHEN LINKCITY1 = 'CHAN' THEN 29" +
                    "WHEN LINKCITY1 = 'SHIM' THEN 30" +
                    "WHEN LINKCITY1 = 'PANI' THEN 31" +
                    "WHEN LINKCITY1 = 'ROHT' THEN 32" +
                    "WHEN LINKCITY1 = 'AMBA' THEN 33" +
                    "WHEN LINKCITY1 = 'HISS' THEN 34" +
                    "WHEN LINKCITY1 = 'REWA' THEN 35" +
                    "WHEN LINKCITY1 = 'FARI' THEN 36" +
                    "WHEN LINKCITY1 = 'NEDN' THEN 37" +
                    "WHEN LINKCITY1 = 'AMRI' THEN 38" +
                    "WHEN LINKCITY1 = 'JALA' THEN 39" +
                    "WHEN LINKCITY1 = 'LUDH' THEN 40" +
                    "WHEN LINKCITY1 = 'PATI' THEN 41" +
                    "WHEN LINKCITY1 = 'BHAT' THEN 42" +
                    "WHEN LINKCITY1 = 'JAMM' THEN 43" +
                    "WHEN LINKCITY1 = 'RANC' THEN 44" +
                    "WHEN LINKCITY1 = 'JAMS' THEN 45" +
                    "WHEN LINKCITY1 = 'DHAN' THEN 46" +
                    "WHEN LINKCITY1 = 'PATN' THEN 47" +
                    "WHEN LINKCITY1 = 'BHAG' THEN 48" +
                    "WHEN LINKCITY1 = 'GAYA' THEN 49" +
                    "WHEN LINKCITY1 = 'MUZA' THEN 50" +
                    "WHEN LINKCITY1 = 'AHME' THEN 51" +
                    "WHEN LINKCITY1 = 'MEHS' THEN 52" +
                    "WHEN LINKCITY1 = 'RAJK' THEN 53" +
                    "WHEN LINKCITY1 = 'JUNA' THEN 54" +
                    "WHEN LINKCITY1 = 'SURA' THEN 55" +
                    "WHEN LINKCITY1 = 'VAPI' THEN 56" +
                    "WHEN LINKCITY1 = 'BARO' THEN 57" +
                    "WHEN LINKCITY1 = 'BHAV' THEN 58" +
                    "WHEN LINKCITY1 = 'MUMB' THEN 59" +
                    "WHEN LINKCITY1 = 'BHUJ' THEN 60" +
                    "WHEN LINKCITY1 = 'AURA' THEN 61" +
                    "WHEN LINKCITY1 = 'AHEM' THEN 62" +
                    "WHEN LINKCITY1 = 'NASI' THEN 63" +
                    "WHEN LINKCITY1 = 'JALG' THEN 64" +
                    "WHEN LINKCITY1 = 'SOLA' THEN 65" +
                    "WHEN LINKCITY1 = 'AKOL' THEN 66" +
                    "WHEN LINKCITY1 = 'AMRA' THEN 67" +
                    "WHEN LINKCITY1 = 'MPPR' THEN 68" +
                    "WHEN LINKCITY1 = 'NOID' THEN 69" +
                    "WHEN LINKCITY1 = 'DNA INDO' THEN 70" +
                    "ELSE 71 END)", _OracleCon);
                    cmd2.ExecuteNonQuery();
                    cmd2.Dispose();
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        public void ChangeDataType(string TableName)
        {
            try
            {
                using (_OracleCon = new OracleConnection(connOracle))
                {
                    _OracleCon.Open();
                    OracleCommand cmd = new OracleCommand("ALTER TABLE " + TableName + " ADD (PRODDATE1 DATE)", _OracleCon);
                    cmd.ExecuteNonQuery();

                    OracleCommand cmd1 = new OracleCommand("UPDATE " + TableName + " SET PRODDATE1=TO_DATE(PRODDATE,'DD-MM-YYYY')", _OracleCon);
                    cmd1.ExecuteNonQuery();

                    OracleCommand cmd2 = new OracleCommand("ALTER TABLE " + TableName + " DROP (PRODDATE)", _OracleCon);
                    cmd2.ExecuteNonQuery();

                    OracleCommand cmd3 = new OracleCommand("ALTER TABLE " + TableName + " RENAME COLUMN PRODDATE1 TO PRODDATE", _OracleCon);
                    cmd3.ExecuteNonQuery();
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        #endregion

        #region "Common DB Methods"
        private DataTable GetCSVRows(string path, bool IsFirstRowHeader)
        {
            DataTable dataTable = null;
            try
            {
                using (LumenWorks.Framework.IO.Csv.CachedCsvReader csv = new
                LumenWorks.Framework.IO.Csv.CachedCsvReader(new StreamReader(path), true, ','))
                {
                    dataTable = new DataTable();
                    // Field headers will automatically be used as column names
                    dataTable.Load(csv);
                }
                //Binding Datagridview
                if (dataGridView1.DataSource == null)
                {
                    dtBindRecords = dataTable.Clone(); // if needed
                    int max = Math.Min(20, dataTable.Rows.Count);
                    for (int i = 0; i < max; i++)
                    {
                        DataRow dr = dtBindRecords.NewRow();
                        dr.ItemArray = dataTable.Rows[i].ItemArray;
                        dtBindRecords.Rows.Add(dr);
                    }
                }
                dataGridView1.Visible = true;
                dataGridView1.DataSource = dtBindRecords;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dataTable;
        }
        #endregion
        #region "File System Method"

        private void HideFolder()
        {
            try
            {
                string path = vCurrnetWD + @"\tmp";
                if (!Directory.Exists(path))
                {
                    DirectoryInfo di = Directory.CreateDirectory(path);
                    di.Attributes = FileAttributes.Directory | FileAttributes.Hidden;
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        #endregion
        #region "SQL Server Methods"
        private void ExportToDb(DataTable dt, string dbTableName)
        {
            try
            {
                if (dt.Rows.Count > 0)
                {
                    if (frmSchedule.Database != 0)
                    {
                        dbType = frmSchedule.Database;
                    }
                    if (dbType == 1) // SQL Server
                    // if (frmSchedule.Database == 1) // SQL Server
                    {
                        try
                        {
                            using (_dconn = new SqlConnection(connStr))
                            {
                                _dconn.Open();
                                // checking whether the table selected from the dataset exists in the database or not
                                try
                                {
                                    if (Globle._globalValue == "" && TableExists == null)
                                    {
                                        SqlCommand cmd = new SqlCommand("SELECT * FROM sysobjects where name = '" + dbTableName + "'", _dconn);
                                        TableExists = cmd.ExecuteScalar().ToString();
                                        if (TableExists == dbTableName)
                                        {
                                            SqlCommand cmd1 = new SqlCommand("TRUNCATE TABLE " + dbTableName + "", _dconn);
                                            cmd1.ExecuteNonQuery();
                                        }
                                        //MessageBox.Show("Table allready exist..!!");
                                        goto oldTbl;
                                    }
                                    else
                                    {
                                        goto oldTbl;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //MessageBox.Show(ex.Message);
                                    TableExists = "Not Same Table";
                                }


                                // selecting each column of the datatable to create a table in the database
                                foreach (DataColumn dc in dt.Columns)
                                {
                                    try
                                    {
                                        dc.ColumnName = dc.ColumnName.Replace("%", "");
                                        //dc.ColumnName = Regex.Replace(dc.ColumnName, "@[^0-9a-zA-Z]+", "");

                                        if (Globle._globalValue == "" && exists == null)
                                        {
                                            SqlCommand createtable = new SqlCommand("CREATE TABLE " + dbTableName + " (" + dc.ColumnName + " varchar(MAX))", _dconn);
                                            createtable.ExecuteNonQuery();
                                            exists = dbTableName;
                                            Globle._globalValue = exists;
                                        }
                                        else
                                        {
                                            SqlCommand addcolumn = new SqlCommand("ALTER TABLE " + dbTableName + " ADD " + dc.ColumnName + " varchar(MAX)", _dconn);
                                            addcolumn.ExecuteNonQuery();
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show(ex.ToString());
                                    }
                                }
                            oldTbl:
                                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(_dconn))
                                {
                                    bulkCopy.DestinationTableName = dbTableName;
                                    bulkCopy.WriteToServer(dt.CreateDataReader());
                                }
                            }
                        }
                        catch (Exception Ex)
                        {
                            MessageBox.Show(Ex.Message);
                        }
                    }
                    else if (dbType == 2) // Oracle
                    //else if (frmSchedule.Database == 2) // Oracle
                    {
                        try
                        {
                            //if (!columnExsistsStatus)
                            //{
                            //    columnExsistsStatus = ColumnExists(dbTableName);
                            //}
                            using (_OracleCon = new OracleConnection(connOracle))
                            {
                                _OracleCon.Open();
                                // checking whether the table selected from the dataset exists in the database or not
                                try
                                {
                                    if (Globle._globalValue == "" && TableExists == null)
                                    {
                                        OracleCommand cmd = new OracleCommand("select * from user_tables where table_name = '" + dbTableName.ToUpper() + "'", _OracleCon);
                                        TableExists = cmd.ExecuteScalar().ToString();
                                        if (TableExists == dbTableName.ToUpper())
                                        {
                                            //OracleCommand cmd1 = new OracleCommand("TRUNCATE TABLE " + dbTableName + "", _OracleCon);
                                            //ALTER TABLE PROD_MAIN1 RENAME TO PROD_MAIN12
                                            OracleCommand cmd1 = new OracleCommand("ALTER TABLE " + dbTableName + " RENAME TO " + dbTableName + DateTime.Now.ToString("ddMMyy") + "", _OracleCon);
                                            cmd1.ExecuteNonQuery();
                                            //if (columnExsistsStatus)
                                            //{
                                            //    OracleCommand cmd2 = new OracleCommand("ALTER TABLE " + dbTableName + " DROP (STATECODE, SORTID, LINKCITYSORTID)", _OracleCon);
                                            //    cmd2.ExecuteNonQuery();
                                            //}
                                        }
                                        //goto oldTbl;
                                    }
                                    else
                                    {
                                        goto oldTbl;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //MessageBox.Show(ex.Message);
                                    TableExists = "No";
                                }
                                // selecting each column of the datatable to create a table in the database
                                string strCreate = string.Empty;
                                string strAlter = string.Empty;
                                foreach (DataColumn dc in dt.Columns)
                                {
                                    try
                                    {
                                        //dc.ColumnName = dc.ColumnName.Replace("%", "");
                                        dc.ColumnName = Regex.Replace(Regex.Replace(dc.ColumnName, "[\\\\/]", "-"), @"[^0-9a-zA-Z\._]", string.Empty);
                                        if (dc.ColumnName.Length > 30)
                                        {
                                            dc.ColumnName = dc.ColumnName.Substring(0, 30);
                                        }
                                        if (dc.ColumnName.ToUpper() == "DATE" || dc.ColumnName.ToUpper() == "CLUSTER")
                                        {
                                            dc.ColumnName = dc.ColumnName + "s";
                                        }
                                        if (Globle._globalValue == "" && exists == null)
                                        {
                                            strCreate = "CREATE TABLE " + dbTableName + " (" + dc.ColumnName + " VARCHAR2 (1000))";
                                            OracleCommand createtable = new OracleCommand(strCreate, _OracleCon);
                                            createtable.ExecuteNonQuery();
                                            exists = dbTableName;
                                            Globle._globalValue = exists;
                                        }
                                        else
                                        {
                                            strAlter = "ALTER TABLE " + dbTableName + " ADD " + dc.ColumnName + " VARCHAR2 (1000)";
                                            OracleCommand addcolumn = new OracleCommand(strAlter, _OracleCon);
                                            addcolumn.ExecuteNonQuery();
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show(ex.ToString());
                                    }
                                }
                            oldTbl:
                                using (OracleBulkCopy bulkCopy = new OracleBulkCopy(_OracleCon))
                                {
                                    bulkCopy.DestinationTableName = dbTableName;
                                    //bulkCopy.BulkCopyTimeout = 0;
                                    bulkCopy.BatchSize = 100000;
                                    bulkCopy.WriteToServer(dt.CreateDataReader());
                                }
                            }
                        }
                        catch (Exception Ex)
                        {
                            MessageBox.Show(Ex.Message);
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void LoadQvdToDataTable(QlikView.Doc docName, string dbTableName)
        {
            try
            {
                Clipboard.Clear();
                dt = new DataTable();

                QlikView.IArrayOfFieldDescription iFields = null;
                iFields = docName.GetFieldDescriptions();
                QlikView.TableBox IStraightTable = null;
                IStraightTable = (QlikView.TableBox)docName.Sheets("Main").CreateTableBox();//.CreateTableBox ();
                for (int j = 0; j <= iFields.Count - 1; j++)
                {
                    QlikView.IFieldDescription IFieldDesc = (QlikView.IFieldDescription)iFields[j];

                    Console.WriteLine("Data Column::" + IFieldDesc.Name.ToString());

                    if (!IFieldDesc.IsSystem)
                    {
                        IStraightTable.AddField(IFieldDesc.Name.ToString());
                        DataColumn Dcol = new DataColumn(IFieldDesc.Name.ToString(), System.Type.GetType("System.String"));
                        dt.Columns.Add(Dcol);
                    }

                }

                IStraightTable.CopyTableToClipboard(true);

                string s = Clipboard.GetText();

                string[] lines = s.Split('\n');
                int vCounter = 0;
                foreach (string line in lines)
                {

                    GetDataInTextFile(line);

                    if (line.Length > 0)
                    {
                        if (vCounter != 0)
                        {
                            DataRow dRow = dt.NewRow();
                            string[] sCells = line.Remove(line.Length - 1).Split('\t');
                            int col = 0;
                            foreach (string sCell in sCells)
                            {
                                dRow[col] = sCell;
                                col = col + 1;
                            }
                            dt.Rows.Add(dRow);
                        }
                        vCounter = vCounter + 1;
                    }
                }
                ExportToDb(dt, dbTableName);
                File.Delete(vCurrnetWD + @"\Backup.txt");
                dt.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                //MessageBox.Show(ex.InnerException.Message);
            }
        }
        #endregion
        #endregion
        #region "Form Methods"
        #region "Default Constructor"
        public frmQReader()
        {
            InitializeComponent();
        }
        #endregion
        #region "Form Load"

        private void frmQReader_Load(object sender, EventArgs e)
        {
            Icon = QReader.Properties.Resources.TrayIcon;
            dataGridView1.Visible = false;
            DataTable dt = new DataTable();
            dt = DisplayRecords();
            ScheduleTime = dt.Rows[0]["Schtime"].ToString();
            chunkLimit = Convert.ToInt32(dt.Rows[0]["CHUNKLIMIT"].ToString());
            timer1.Start();
        }

        #endregion
        #region "Unload Form"
        private void frmQReader_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
        }

        #endregion
        #endregion

        #region "Splitter"
        public void SplitCSV(string FilePath, int LineCount, int MaxOutputFile)
        {
            System.IO.StreamReader Reader = new System.IO.StreamReader(FilePath);
            try
            {
                // Open the csv file for reading

                // Create the output directory
                string OutputFolder = vCurrnetWD + @"\tmp";

                // Read the csv column's header
                string strHeader = Reader.ReadLine();

                // Start splitting
                int FileIndex = 0;
                do
                {
                    // Update progress
                    FileIndex += 1;

                    // Check if the number of splitted files doesn't exceed the limit
                    if ((MaxOutputFile < FileIndex) & (MaxOutputFile > 0))
                        break; // TODO: might not be correct. Was : Exit Do

                    // Create new file to store a piece of the csv file
                    string PiecePath = OutputFolder + "\\" + Path.GetFileNameWithoutExtension(FilePath) + "_" + FileIndex + Path.GetExtension(FilePath);
                    StreamWriter Writer = new StreamWriter(PiecePath, false);
                    Writer.AutoFlush = false;
                    Writer.WriteLine(strHeader);

                    // Read and writes precise number of rows
                    for (int i = 1; i <= LineCount; i++)
                    {
                        string s = Reader.ReadLine();
                        if (s != null)
                        {
                            Writer.WriteLine(s);
                        }
                        else
                        {
                            Writer.Flush();
                            Writer.Close();
                            break; // TODO: might not be correct. Was : Exit Do
                        }
                    }
                    // Flush and close the splitted file
                    Writer.Flush();
                    Writer.Close();

                } while (true);

                // Reader.Close();
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
            finally
            {
                Reader.Close();
            }
        }
        #endregion

        /******************************************Take Data From Qvd In Txt File*********By Sanjay kumar**08-08-2015*******************************/
        public void GetDataInTextFile(String Line)
        {
            try
            {
                //StreamWriter file2 = new StreamWriter(@"C:\Users\TIMINDMAP\Desktop\QvdExtractor_x64_Source_COde\QvdExtractor_x64_Source_COde\bin\Backup.txt", true);

                //StreamWriter file2 = new StreamWriter(@"D:\Sanjay Folder\PROJECTS\Projects\QlikViewPlugins\Sanjay Code Of Qlik View\QlikView\QvdFiles\Backup.txt", true);
                StreamWriter file2 = new StreamWriter(vCurrnetWD + @"\Backup.txt", true);
                file2.WriteLine("\n\n" + Line);
                file2.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void CreateTextFile()
        {
            try
            {
                String path = Environment.CurrentDirectory + "\\Backup.txt";
                MessageBox.Show(path);
                File.Create(path).Dispose();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            try
            {
                frmSchedule Schedule = new frmSchedule();
                Schedule.ShowDialog();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            try
            {
                if (ScheduleQvdPath != "")
                {
                    OpenQlikview(ScheduleQvdPath);
                }
                else
                {
                    MessageBox.Show("Please Select Folder Before Extract");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        public void OpenQlikview(string strQvdPath)
        {
            try
            {
                string[] filePaths = Directory.GetFiles(strQvdPath, "*.qvd");
                if (filePaths.Length > 0)
                {
                    System.Diagnostics.ProcessStartInfo myProc = new System.Diagnostics.ProcessStartInfo();
                    myProc.FileName = qvExcPath;
                    myProc.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    System.Diagnostics.Process.Start(myProc);
                    objQVApp = new QlikView.Application();

                    foreach (string strName in filePaths)
                    {
                        Extract(strName, strQvdPath);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select Folder Which Contains Atleast 1 .qvd File");
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        public void Extract(string strQvdName, string strQvdPath)
        {
            try
            {
                string[] lines = strQvdName.Split('~');
                foreach (string line in lines)
                {
                    string dbTableName = Path.GetFileNameWithoutExtension(strQvdName);
                    string QvdName = Path.GetFileName(strQvdName);

                    if (performanceView.Equals("2"))
                    {
                        objMetaInformation = new QlikViewMeta.MetaDataQvd(strQvdPath + @"\" + QvdName);
                        DirectLoadQvdData(QvdName, objMetaInformation.QvdNoOfRecords, dbTableName);
                    }
                    else
                    {
                        objMetaInformation = new QlikViewMeta.MetaDataQvd(strQvdPath + @"\" + QvdName);
                        IntermediateLoad(QvdName, (double)objMetaInformation.QvdNoOfRecords, dbTableName, strQvdPath);
                    }
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                HideFolder();
                string filePath = SelectQvdFile();
                txtFileName.Text = filePath;
                if (filePath == "")
                { return; }
                else
                {
                    ScheduleQvdPath = filePath;
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                string currTime = DateTime.Now.ToString("HH:mm");
                if (currTime == ScheduleTime && ScheduleQvdPath != "")
                {
                    OpenQlikview(ScheduleQvdPath);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        public DataTable DisplayRecords()
        {
            DataTable dt = new DataTable();
            try
            {
                using (_OracleCon = new OracleConnection(connOracle))
                {
                    _OracleCon.Open();
                    string Query = "Select InsertDB,ChunkLimit,SchTime from Schedule";
                    OracleDataAdapter oraAdapt = new OracleDataAdapter(Query, _OracleCon);
                    oraAdapt.Fill(dt);
                    _OracleCon.Close();

                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
            return dt;
        }
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  