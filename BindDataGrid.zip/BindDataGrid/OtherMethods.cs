﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QReader
{
    public class OtherMethods
    {
        //static internal class OtherMethods

        private static frmQReader PF;
        public void ExitApplication()
        {
            //Perform any clean-up here
            //Then exit the application
            Application.Exit();
        }
        public void ShowDialog()
        {
            try
            {
                if (PF != null && !PF.IsDisposed)
                    return;
                bool CloseApp = false;
                PF = new frmQReader();
                PF.ShowDialog();
                CloseApp = (PF.DialogResult == DialogResult.Abort);
                PF = null;
                if (CloseApp)
                    Application.Exit();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

    }
}
