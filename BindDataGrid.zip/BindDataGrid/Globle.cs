﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QReader
{
    class Globle
    {
        public static string _globalValue = "";
        public static string GlobalValue
        {
            get
            {
                return _globalValue;
            }
            set
            {
                _globalValue = value;
            }
        }

        public static string filePath = "";
        public static string FilePath
        {
            get
            {
                return filePath;
            }
            set
            {
                filePath = value;
            }
        }

    }
}
