﻿namespace QReader
{
    partial class frmSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SQLDATABASE = new System.Windows.Forms.RadioButton();
            this.ORACLEDATABASE = new System.Windows.Forms.RadioButton();
            this.lblChunkLimit = new System.Windows.Forms.Label();
            this.lblExtractingTime = new System.Windows.Forms.Label();
            this.txtChunkLimit = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblNumOfRecords = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // SQLDATABASE
            // 
            this.SQLDATABASE.AutoSize = true;
            this.SQLDATABASE.Location = new System.Drawing.Point(28, 31);
            this.SQLDATABASE.Name = "SQLDATABASE";
            this.SQLDATABASE.Size = new System.Drawing.Size(93, 17);
            this.SQLDATABASE.TabIndex = 0;
            this.SQLDATABASE.Text = "SQL SERVER";
            this.SQLDATABASE.UseVisualStyleBackColor = true;
            // 
            // ORACLEDATABASE
            // 
            this.ORACLEDATABASE.AutoSize = true;
            this.ORACLEDATABASE.Location = new System.Drawing.Point(129, 31);
            this.ORACLEDATABASE.Name = "ORACLEDATABASE";
            this.ORACLEDATABASE.Size = new System.Drawing.Size(68, 17);
            this.ORACLEDATABASE.TabIndex = 1;
            this.ORACLEDATABASE.Text = "ORACLE";
            this.ORACLEDATABASE.UseVisualStyleBackColor = true;
            // 
            // lblChunkLimit
            // 
            this.lblChunkLimit.AutoSize = true;
            this.lblChunkLimit.Location = new System.Drawing.Point(35, 94);
            this.lblChunkLimit.Name = "lblChunkLimit";
            this.lblChunkLimit.Size = new System.Drawing.Size(76, 13);
            this.lblChunkLimit.TabIndex = 2;
            this.lblChunkLimit.Text = "CHUNK LIMIT";
            // 
            // lblExtractingTime
            // 
            this.lblExtractingTime.AutoSize = true;
            this.lblExtractingTime.Location = new System.Drawing.Point(25, 140);
            this.lblExtractingTime.Name = "lblExtractingTime";
            this.lblExtractingTime.Size = new System.Drawing.Size(86, 13);
            this.lblExtractingTime.TabIndex = 3;
            this.lblExtractingTime.Text = "EXTRACT TIME";
            // 
            // txtChunkLimit
            // 
            this.txtChunkLimit.Location = new System.Drawing.Point(155, 87);
            this.txtChunkLimit.Name = "txtChunkLimit";
            this.txtChunkLimit.Size = new System.Drawing.Size(100, 20);
            this.txtChunkLimit.TabIndex = 4;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(129, 200);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "SUBMIT";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lblNumOfRecords
            // 
            this.lblNumOfRecords.AutoSize = true;
            this.lblNumOfRecords.Location = new System.Drawing.Point(35, 60);
            this.lblNumOfRecords.Name = "lblNumOfRecords";
            this.lblNumOfRecords.Size = new System.Drawing.Size(0, 13);
            this.lblNumOfRecords.TabIndex = 7;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "HH:mm";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker1.Location = new System.Drawing.Point(155, 140);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateTimePicker1.ShowUpDown = true;
            this.dateTimePicker1.Size = new System.Drawing.Size(84, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // frmSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 337);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblNumOfRecords);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtChunkLimit);
            this.Controls.Add(this.lblExtractingTime);
            this.Controls.Add(this.lblChunkLimit);
            this.Controls.Add(this.ORACLEDATABASE);
            this.Controls.Add(this.SQLDATABASE);
            this.Name = "frmSchedule";
            this.Text = "Schedule";
            this.Load += new System.EventHandler(this.frmSchedule_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton SQLDATABASE;
        private System.Windows.Forms.RadioButton ORACLEDATABASE;
        private System.Windows.Forms.Label lblChunkLimit;
        private System.Windows.Forms.Label lblExtractingTime;
        private System.Windows.Forms.TextBox txtChunkLimit;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblNumOfRecords;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}