﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace QReader
{
    public partial class Browse : Form
    {
        #region "QlikView Variables"
        private QlikView.Application objQVApp = null;
        private QlikView.Doc IDoc = null;
        private QlikView.Variable IQvVariables = null;
        private QlikViewMeta.MetaDataQvd objMetaInformation = null;
        private string qvExcPath = System.Configuration.ConfigurationManager.AppSettings["QlikViewExePath"].ToString();
        private string strQvdPath = System.Configuration.ConfigurationSettings.AppSettings["QvdPath"].ToString();
        public static string ScheduleQvdName = string.Empty;
        public static string ScheduleQvdPath = string.Empty;
        private string strQvdName = System.Configuration.ConfigurationSettings.AppSettings["QvdsName"].ToString();
        private string vCurrnetWD = Environment.CurrentDirectory.ToString();
        #endregion
        public Browse()
        {
            InitializeComponent();
        }

        private void Browse_Load(object sender, EventArgs e)
        {
           // Sample();
        }
        public void Sample()
        {
            //HideFolder();
            //string fileName = SelectQvdFile();
            //if (fileName == "")
            //{ return; }
            //else
            //{
            //    string[] tblName = fileName.Split('.');
            //    strQvdName = fileName + ":" + tblName[0].ToString();
            //    ScheduleQvdName = strQvdName;
            //    strQvdPath = Globle.filePath;
            //    ScheduleQvdPath = strQvdPath;
            //}
           
            //System.Diagnostics.ProcessStartInfo myProc = new System.Diagnostics.ProcessStartInfo();
            //myProc.FileName = qvExcPath;
            //myProc.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            //System.Diagnostics.Process.Start(myProc);
            //objQVApp = new QlikView.Application();
            //IDoc = (QlikView.Doc)objQVApp.OpenDocEx(vCurrnetWD + @"\QvdLoader.qvw", 0, false, "", "", "9108 6600 9616 4267", false);
            //IDoc.Activate();
            //IQvVariables = (QlikView.Variable)IDoc.Variables("vQvdName");
            //IQvVariables.SetContent("set ErrorMode=0;  tmpQvd:" + Environment.NewLine + " Load * from [" + strQvdPath + @"\" + fileName + "](qvd);if ScriptError=2 or ScriptError=3 or ScriptError=4 or ScriptError=5 or ScriptError=6 or ScriptError=7 or ScriptError=8 or ScriptError=9 or ScriptError=10 then " + Environment.NewLine + " exit script" + Environment.NewLine + "else" + Environment.NewLine + "store tmpQvd into " + vCurrnetWD + @"\tmp\tmpQvd.csv(txt, delimiter is ',');" + Environment.NewLine + " end if ; ", true);
            ////IQvVariables.SetContent("ODBC CONNECT TO [ODBCOracleConnect;DBQ=MYDB](XUserID is qvddata, XPassword is qvd1234$, mode is write);TABLE:LOAD * FROM [D:Files\\TestingQVD\\Test.qvd] (qvd);LET V_ROWS = NoOfRows('TABLE');FOR V_ROW = 0 TO V_ROWS - 1LET V_FIELD1 = Peek('Id',V_ROW);LET V_FIELD2 = Peek('Name',V_ROW);LET V_FIELD3 = Peek('Description',V_ROW);SQL INSERT INTO SampleTable(Id, Name,Description) VALUES ('$(V_FIELD1)', '$(V_FIELD2)', '$(V_FIELD3)');NEXT;", true);
            //IDoc.ReloadEx(2, 1);
            //IDoc.CloseDoc();
            this.Hide();
        }
        //public string SelectQvdFile()
        //{
        //    string fileName = "";
        //    //string filePath = "";
        //    try
        //    {
        //        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        //        openFileDialog1.InitialDirectory = @"C:\";
        //        openFileDialog1.Title = "Browse Text Files";
        //        openFileDialog1.CheckFileExists = true;
        //        openFileDialog1.CheckPathExists = true;
        //        openFileDialog1.DefaultExt = "qvd";
        //        openFileDialog1.Filter = "Qvd files (*.qvd)|*.qvd|All files (*.*)|*.*";
        //        openFileDialog1.FilterIndex = 1;
        //        openFileDialog1.RestoreDirectory = true;
        //        openFileDialog1.ReadOnlyChecked = true;
        //        openFileDialog1.ShowReadOnly = true;
        //        if (openFileDialog1.ShowDialog() == DialogResult.OK)
        //        {
        //            fileName = openFileDialog1.SafeFileName;
        //            Globle.filePath = Path.GetDirectoryName(openFileDialog1.FileName);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("");
        //    }
        //    return fileName;
        //}
        //private void HideFolder()
        //{
        //    string path = vCurrnetWD + @"\tmp";
        //    if (!Directory.Exists(path))
        //    {
        //        DirectoryInfo di = Directory.CreateDirectory(path);
        //        di.Attributes = FileAttributes.Directory | FileAttributes.Hidden;
        //    }
        //}
    }
}
