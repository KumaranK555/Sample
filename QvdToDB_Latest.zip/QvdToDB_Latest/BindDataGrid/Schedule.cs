﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Oracle.DataAccess.Client;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data.Odbc;
using System.Diagnostics;
using System.Timers;
using System.Threading;
using System.Globalization;
namespace QReader
{
    public partial class frmSchedule : Form
    {
        private OracleConnection _OracleCon = null;
        private string connOracle = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionStringOracle"].ConnectionString.ToString();
        public static string strQvdName = "";
        public static string strQvdPath = "";
        public static int ChunkLimit;
        public static int Database;
        public string ExtractingTime = string.Empty;
        int noOfRows;
        string schedulerTime = string.Empty;
        frmQReader qReader = new frmQReader();
        public frmSchedule()
        {
            InitializeComponent();
        }

        private void frmSchedule_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                dt = qReader.DisplayRecords();
                EditSettings(dt);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                ChunkLimit = Convert.ToInt32(txtChunkLimit.Text);
                schedulerTime = dateTimePicker1.Value.ToString("HH:mm");
                frmQReader.ScheduleTime = schedulerTime;
                if (SQLDATABASE.Checked == true)
                {
                    Database = 1;
                }
                else if (ORACLEDATABASE.Checked == true)
                {
                    Database = 2;
                }
                using (_OracleCon = new OracleConnection(connOracle))
                {
                    _OracleCon.Open();
                    // checking whether the table selected from the dataset exists in the database or not
                    string exists = null;
                    try
                    {
                        if (noOfRows > 0)
                        {
                            OracleCommand cmd = new OracleCommand("Update Schedule set InsertDB=" + Database + ",ChunkLimit = " + ChunkLimit + ",Schtime = '" + schedulerTime + "'", _OracleCon);
                            exists = cmd.ExecuteScalar().ToString();
                        }
                        else
                        {
                            OracleCommand cmd = new OracleCommand("Insert Into Schedule (InsertDB, ChunkLimit, Schtime) values (" + Database + ", " + ChunkLimit + ", " + schedulerTime + ")", _OracleCon);
                            exists = cmd.ExecuteScalar().ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        exists = null;
                    }
                }
                this.Close();
            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }

        private void EditSettings(DataTable dt)
        {
            try
            {
                if (dt.Rows.Count > 0)
                {
                    using (_OracleCon = new OracleConnection(connOracle))
                    {
                        _OracleCon.Open();
                        // checking whether the table selected from the dataset exists in the database or not
                        try
                        {
                            OracleCommand cmd = new OracleCommand("SELECT COUNT(*) FROM SCHEDULE", _OracleCon);
                            noOfRows = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }

                        if (Convert.ToInt32(dt.Rows[0]["INSERTDB"]) == 1)
                        {
                            SQLDATABASE.Checked = true;
                        }
                        else
                        {
                            ORACLEDATABASE.Checked = true;
                        }
                        txtChunkLimit.Text = Convert.ToInt32(dt.Rows[0]["CHUNKLIMIT"]).ToString();
                        string currtime = DateTime.Now.ToShortDateString() + " " + dt.Rows[0]["SCHTIME"].ToString();
                        dateTimePicker1.Value = Convert.ToDateTime(currtime);
                    }
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
    }
}
