﻿//'****************************************************************************************************************
//'*          Company Name            :   Team Computers Pvt. Ltd.
//'*          Project Title           :   Qvd-Reader
//'*          Created By              :   Manish Bhandari
//'*          Reviewed By             :   A. Rajendran
//'*          Created On              :   7-Feb-2011
//'*          Last Modified On        :   
//'*          Last Modified By        :   
//'*          Remarks                 :   
//'***************************************************************************************************************
#region Using Directives
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using QlikView;
using System.Data.OleDb;
using System.Globalization;
using System.Data.SqlClient;
using Oracle.DataAccess.Client ;// .Data.OracleClient;
#endregion
namespace QReader
{
    public partial class frmQReader : Form
    {

        #region "QlikView Variables"
        private QlikView.ApplicationClass objQVApp = null;
        private QlikView.Doc IDoc = null;
        private QlikView.Variable IQvVariables = null;
        private QlikViewMeta.MetaDataQvd objMetaInformation = null;
        

        #endregion
        #region "Sql Server Variables"
        private SqlConnection _dconn = null;
        #endregion
        #region "Oracle Variables"
        private OracleConnection _OracleCon = null;
       
        #endregion
        #region "MySql variables"
        #endregion
        #region "DB2Variables"
        #endregion
        #region "App Settings Variables"
        private string strQvdPath = System.Configuration.ConfigurationSettings.AppSettings["QvdPath"].ToString();
        private string strQvdName = System.Configuration.ConfigurationSettings.AppSettings["QvdsName"].ToString();
        private string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["SqlConnectionString"].ConnectionString.ToString();
        private int dbType = Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings["DbType"].ToString());
        private long RowsLimit = Convert.ToInt64(System.Configuration.ConfigurationSettings.AppSettings["RowsLimit"].ToString());
        private string performanceView = System.Configuration.ConfigurationSettings.AppSettings["QvdReadView"].ToString();
        private string connOracle = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionStringOracle"].ConnectionString.ToString();
        private string qvExcPath = System.Configuration.ConfigurationManager.AppSettings["QlikViewExePath"].ToString();
        private int chunkLimit = Convert.ToInt32(System.Configuration.ConfigurationSettings.AppSettings["ChunkLimit"].ToString());
        private string DateFormat = System.Configuration.ConfigurationSettings.AppSettings["DateForMatOracle"].ToString();

        #endregion
        #region "Common Variables"
        private string vCurrnetWD = Environment.CurrentDirectory.ToString();
        private DataTable dt = null;
        #endregion
        #region "Methods"
        #region "QlikView Methods"
        private void LaunchQv()
        {
            try
            {
                HideFolder();
                System.Diagnostics.ProcessStartInfo myProc = new System.Diagnostics.ProcessStartInfo();
                myProc.FileName = qvExcPath;
                myProc.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                System.Diagnostics.Process.Start(myProc);


                objQVApp = new ApplicationClass();
                

                string[] lines = strQvdName.Split('~');
                foreach (string line in lines)
                {
                    string dbTableName = line.Substring(line.LastIndexOf(":") + 1).Trim();
                    string QvdName = line.Substring(0, line.LastIndexOf(":")).Trim();

                    if (performanceView.Equals("2"))
                    {
                        objMetaInformation = new QlikViewMeta.MetaDataQvd(strQvdPath + @"\" + QvdName);
                        DirectLoadQvdData(QvdName, objMetaInformation.QvdNoOfRecords, dbTableName);
                    }
                    else
                    {
                        objMetaInformation = new QlikViewMeta.MetaDataQvd(strQvdPath + @"\" + QvdName);
                        IntermediateLoad(QvdName, (double)objMetaInformation.QvdNoOfRecords, dbTableName);
                    }
                }

            }
            catch (Exception exQv)
            {
                MessageBox.Show(exQv.Message);
                MessageBox.Show(exQv.InnerException.Message);    
            }
            finally
            {

                objQVApp.Quit(1);

            }

        }
        private void DirectLoadQvdData(string pQvdName, long totalNoOfrecords, string dbTableName)
        {
            try
            {

                long j = 0;
                double k = Math.Floor((double)totalNoOfrecords / RowsLimit);
                if (k <= 0)
                {
                    RowsLimit = totalNoOfrecords;
                }
                while (j <= totalNoOfrecords)
                {
                    IDoc = (QlikView.Doc)objQVApp.OpenDocEx(vCurrnetWD + @"\QvdLoader.qvw", 0, false, "", "", "4604460456195450",false);
                    IDoc.Activate();
                    IQvVariables = (QlikView.Variable)IDoc.Variables("vQvdName");

                    IQvVariables.SetContent("tmpQvd:" + Environment.NewLine + " Load * from [" + strQvdPath + @"\" + pQvdName + "](qvd) where recno()>" + j + " and recno()<=" + RowsLimit + ";", true);
                    //IDoc.Reload(1);
                    IDoc.ReloadEx(2, 1);
                    LoadQvdToDataTable(IDoc, dbTableName);
                    IDoc.CloseDoc();
                    j = RowsLimit;
                    RowsLimit = RowsLimit + RowsLimit;
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.InnerException.Message);    
            }
            finally
            {

            }
        }
       
        private void IntermediateLoad(string pQvdName,double noOfRows, string dbTableName)
        {
            try
            {
                
                IDoc = (QlikView.Doc)objQVApp.OpenDocEx(vCurrnetWD + @"\QvdLoader.qvw", 0, false, "", "", "4604 4604 5619 5450", false);
                IDoc.Activate();
                IQvVariables = (QlikView.Variable)IDoc.Variables("vQvdName");
                IQvVariables.SetContent("set ErrorMode=0;  tmpQvd:" + Environment.NewLine + " Load * from [" + strQvdPath + @"\" + pQvdName + "](qvd);if ScriptError=2 or ScriptError=3 or ScriptError=4 or ScriptError=5 or ScriptError=6 or ScriptError=7 or ScriptError=8 or ScriptError=9 or ScriptError=10 then " + Environment.NewLine + " exit script" + Environment.NewLine + "else" + Environment.NewLine + "store tmpQvd into " + vCurrnetWD + @"\tmp\tmpQvd.csv(txt, delimiter is ',');" + Environment.NewLine + " end if ; ", true);
                IDoc.ReloadEx(2, 1);
                IDoc.CloseDoc();

                if (noOfRows > 0)
                {

                    double cLimit = Math.Floor((double)noOfRows / chunkLimit);
                    SplitCSV(vCurrnetWD + @"\tmp\tmpQvd.csv", (int)cLimit + 1, chunkLimit);
                    File.Delete(vCurrnetWD + @"\tmp\tmpQvd.csv");
                    for (int i = 1; i < chunkLimit + 1; i++)
                    {
                        ExportToDb(GetCSVRows(vCurrnetWD + @"\tmp\tmpQvd_" + i + ".csv", true), dbTableName);
                        File.Delete(vCurrnetWD + @"\tmp\tmpQvd_" + i + ".csv");
                    }
                }


            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
                //MessageBox.Show(ex.InnerException.Message);   
            }
        }
        #endregion
       
        #region "Common DB Methods"
        private DataTable GetCSVRows(string path, bool IsFirstRowHeader)
        {
            DataTable dataTable = null;
            try
            {
                

                using (LumenWorks.Framework.IO.Csv.CachedCsvReader csv = new
               LumenWorks.Framework.IO.Csv.CachedCsvReader(new StreamReader(path), true,','))
                {
                    dataTable = new DataTable();
                    // Field headers will automatically be used as column names
                    dataTable.Load(csv);
                }
              //  
                

            }
            catch (Exception ex)
            {
             //   MessageBox.Show(ex.Message);
              //  MessageBox.Show(ex.InnerException.Message);    
            }
            
            return dataTable;
        }
        #endregion
        #region "File System Method"

        private void HideFolder()
        {


            string path = vCurrnetWD + @"\tmp";
            if (!Directory.Exists(path))
            {
                DirectoryInfo di = Directory.CreateDirectory(path);
                di.Attributes = FileAttributes.Directory | FileAttributes.Hidden;
            }
        }


        #endregion
        #region "SQL Server Methods"
        private void ExportToDb(DataTable dt, string dbTableName)
        {
            if (dt.Rows.Count > 0)
            {
                if (dbType == 1) // SQL Server
                {
                    using (_dconn = new SqlConnection(connStr))
                    {
                        _dconn.Open();
                        using (SqlBulkCopy bulkCopy = new SqlBulkCopy(_dconn))
                        {
                            //bulkCopy.ColumnMappings.Add("Name", "EmployeeName");
                            // bulkCopy.BatchSize = 10000;
                            // bulkCopy.BulkCopyTimeout = int.Parse(ConfigurationSettings.AppSettings["timeout"]);
                            bulkCopy.DestinationTableName = dbTableName;
                            bulkCopy.WriteToServer(dt.CreateDataReader());
                        }
                    }

                }
                else if (dbType == 2) // Oracle
                {
                    StringBuilder sb = new StringBuilder();
                    StringBuilder sb1 = new StringBuilder();
                    int countRows = 0;
                    foreach (DataColumn dc in dt.Columns)
                    {

                        sb.Append(dc.ColumnName.ToString() + ",");
                        if (countRows == 0)
                        {
                            sb1.Append(dc.ColumnName.ToString() + ",");
                        }
                        else
                        {
                            sb1.Append(":" + dc.ColumnName.ToString() + ",");
                        }
                        countRows = countRows + 1;
                    }
                    string sql = "INSERT INTO " + dbTableName + "(" + sb.ToString().Substring(0, sb.ToString().Length - 1).ToString() + ")" + "Values(:" + sb1.ToString().Substring(0, sb1.ToString().Length - 1) + ")";
                    using (_OracleCon = new OracleConnection(connOracle))
                    {
                        _OracleCon.Open();
                        OracleCommand cmd = _OracleCon.CreateCommand();
                        cmd.CommandText = sql;
                        cmd.CommandType = CommandType.Text;
                        cmd.BindByName = true;

                        cmd.ArrayBindCount = dt.Rows.Count;

                        foreach (DataColumn dc in dt.Columns)
                        {
                            System.Collections.ArrayList lst = new System.Collections.ArrayList();
                            foreach (DataRow dr in dt.Rows)
                            {
                                lst.Add(dr[dc.ToString()]);
                            }

                            cmd.Parameters.Add(":" + dc.ColumnName.ToString(), OracleDbType.NVarchar2, lst.ToArray(), ParameterDirection.Input);

                        }
                        OracleCommand cmd1 = _OracleCon.CreateCommand();
                        cmd1.CommandText = "ALTER SESSION SET NLS_DATE_FORMAT = '" + DateFormat.Trim()  + "'";
                        cmd1.ExecuteNonQuery();
                        cmd.ExecuteNonQuery();
                        _OracleCon.Close();

                    }
                }
            }
        }
        private void LoadQvdToDataTable(QlikView.Doc docName, string dbTableName)
        {
            try
            {
                Clipboard.Clear();
                dt = new DataTable();

                QlikView.IArrayOfFieldDescription iFields = null;
                iFields = docName.GetFieldDescriptions();
                QlikView.TableBox IStraightTable = null;
                IStraightTable = (QlikView.TableBox)docName.Sheets("Main").CreateTableBox();//.CreateTableBox ();
                for (int j = 0; j <= iFields.Count - 1; j++)
                {
                    QlikView.IFieldDescription IFieldDesc = (QlikView.IFieldDescription)iFields[j];
                    if (!IFieldDesc.IsSystem)
                    {
                        IStraightTable.AddField(IFieldDesc.Name.ToString());
                        DataColumn Dcol = new DataColumn(IFieldDesc.Name.ToString(), System.Type.GetType("System.String"));
                        dt.Columns.Add(Dcol);
                    }

                }



                IStraightTable.CopyTableToClipboard(true);

                string s = Clipboard.GetText();

                string[] lines = s.Split('\n');
                int vCounter = 0;
                foreach (string line in lines)
                {
                    if (line.Length > 0)
                    {
                        if (vCounter != 0)
                        {
                            DataRow dRow = dt.NewRow();
                            string[] sCells = line.Remove(line.Length - 1).Split('\t');
                            int col = 0;
                            foreach (string sCell in sCells)
                            {
                                dRow[col] = sCell;
                                col = col + 1;
                            }
                            dt.Rows.Add(dRow);
                        }
                        vCounter = vCounter + 1;
                    }
                }
                ExportToDb(dt, dbTableName);
                dt.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(ex.InnerException.Message);    
            }
        }
        #endregion
        #endregion
        #region "Form Methods"
        #region "Default Constructor"
        public frmQReader()
        {
            InitializeComponent();
        }
        #endregion
        #region "Form Load"

        private void frmQReader_Load(object sender, EventArgs e)
        {
            LaunchQv();
            this.Dispose();


        }

        #endregion
        #region "Unload Form"
        private void frmQReader_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
        }

        #endregion
        #endregion

        #region "Splitter"
        public void SplitCSV(string FilePath, int LineCount, int MaxOutputFile)
        {
            System.IO.StreamReader Reader = new System.IO.StreamReader(FilePath);

            try
            {
                // Open the csv file for reading

                // Create the output directory
                string OutputFolder = vCurrnetWD + @"\tmp";

                // Read the csv column's header
                string strHeader = Reader.ReadLine();

                // Start splitting
                int FileIndex = 0;


                do
                {
                    // Update progress
                    FileIndex += 1;

                    // Check if the number of splitted files doesn't exceed the limit
                    if ((MaxOutputFile < FileIndex) & (MaxOutputFile > 0))
                        break; // TODO: might not be correct. Was : Exit Do

                    // Create new file to store a piece of the csv file
                    string PiecePath = OutputFolder + "\\" + Path.GetFileNameWithoutExtension(FilePath) + "_" + FileIndex + Path.GetExtension(FilePath);
                    StreamWriter Writer = new StreamWriter(PiecePath, false);
                    Writer.AutoFlush = false;
                    Writer.WriteLine(strHeader);

                    // Read and writes precise number of rows

                    for (int i = 1; i <= LineCount; i++)
                    {
                        string s = Reader.ReadLine();
                        if (s != null)
                        {
                            Writer.WriteLine(s);
                        }
                        else
                        {
                            Writer.Flush();
                            Writer.Close();
                            break; // TODO: might not be correct. Was : Exit Do
                        }

                    }

                    // Flush and close the splitted file
                    Writer.Flush();
                    Writer.Close();

                } while (true);

               // Reader.Close();
            }
            catch (Exception ex)
            {
            //    MessageBox.Show(ex.Message);
             //   MessageBox.Show(ex.InnerException.Message);   
            }
            finally
            {
                Reader.Close();
            }


        }
        #endregion
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  