﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QReader
{
    public class AppContext : ApplicationContext
    {
        OtherMethods _otherMethod = new OtherMethods();
        #region " Storage "
        private NotifyIcon withEventsField_Tray;
        private NotifyIcon Tray
        {
            get { return withEventsField_Tray; }
            set
            {
                if (withEventsField_Tray != null)
                {
                    withEventsField_Tray.DoubleClick -= Tray_DoubleClick;
                }
                withEventsField_Tray = value;
                if (withEventsField_Tray != null)
                {
                    withEventsField_Tray.DoubleClick += Tray_DoubleClick;
                }
            }
        }
        private ContextMenuStrip MainMenu;
        private ToolStripMenuItem withEventsField_mnuDisplayForm;
        private ToolStripMenuItem mnuDisplayForm
        {
            get { return withEventsField_mnuDisplayForm; }
            set
            {
                if (withEventsField_mnuDisplayForm != null)
                {
                    withEventsField_mnuDisplayForm.Click -= mnuDisplayForm_Click;
                }
                withEventsField_mnuDisplayForm = value;
                if (withEventsField_mnuDisplayForm != null)
                {
                    withEventsField_mnuDisplayForm.Click += mnuDisplayForm_Click;
                }
            }
        }
        private ToolStripSeparator mnuSep1;
        private ToolStripMenuItem withEventsField_mnuExit;
        private ToolStripMenuItem mnuExit
        {
            get { return withEventsField_mnuExit; }
            set
            {
                if (withEventsField_mnuExit != null)
                {
                    withEventsField_mnuExit.Click -= mnuExit_Click;
                }
                withEventsField_mnuExit = value;
                if (withEventsField_mnuExit != null)
                {
                    withEventsField_mnuExit.Click += mnuExit_Click;
                }
            }
        }
        #endregion
        #region " Constructor "
        public AppContext()
        {
            ThreadExit += AppContext_ThreadExit;
            //Initialize the menus
            mnuDisplayForm = new ToolStripMenuItem("Display form");
            mnuSep1 = new ToolStripSeparator();
            mnuExit = new ToolStripMenuItem("Exit");
            MainMenu = new ContextMenuStrip();
            MainMenu.Items.AddRange(new ToolStripItem[] {
			mnuDisplayForm,
			mnuSep1,
			mnuExit
		});
            //Initialize the tray
            Tray = new NotifyIcon();
            Tray.Icon = QReader.Properties.Resources.TrayIcon;
            Tray.ContextMenuStrip = MainMenu;
            Tray.Text = "Formless tray application";
            //Display
            Tray.Visible = true;
        }
        #endregion
        #region " Event handlers "
        private void AppContext_ThreadExit(object sender, System.EventArgs e)
        {
            //Guarantees that the icon will not linger.
            Tray.Visible = false;
        }
        private void mnuDisplayForm_Click(object sender, System.EventArgs e)
        {
            _otherMethod.ShowDialog();
        }
        private void mnuExit_Click(object sender, System.EventArgs e)
        {
            _otherMethod.ExitApplication();
        }
        private void Tray_DoubleClick(object sender, System.EventArgs e)
        {
            _otherMethod.ShowDialog();
        }
        #endregion
    }
}
